AMINA BIRTHDAY SURPRISE — UPDATED

Name: Amina
Birthday: 14 April 2008
Theme: Maroon + Gold
Countdown: 10 seconds after page load
Auto-scroll: 20 seconds per chapter
Memory password: 0414
Song: Khaab.mp4 starts when the 10-second countdown reaches zero and is not looped.

NEW PHOTOS:
- The photos supplied in dp.zip are now used as the birthday reveal + vertical memories.
- Old memory gallery images are not referenced by the memory section.
- Birthday reveal photo: assets/birthday-person.jpg
- Memory photos: assets/new-memories/

CAKE:
- Redesigned as a larger, decorative 4-pound cake in maroon/gold.
- Click each candle to extinguish it.
- Click the cake to cut it.

NOTE:
Browser autoplay policies may block sound. The Khaab audio/video control is available at the end if that happens.
